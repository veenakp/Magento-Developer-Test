<?php

namespace DL\CustomModule\Observer;

use Magento\Framework\Event\ObserverInterface;
use DL\CustomModule\Api\CustomRepositoryInterface;
use DL\CustomModule\Api\Data\CustomInterfaceFactory;
use Magento\Framework\App\RequestInterface;
use DL\CustomModule\Model\ResourceModel\Custom\CollectionFactory;


class Productsaveafter implements ObserverInterface
{
    public function __construct(
        CustomInterfaceFactory $customInterfaceFactory,
        CustomRepositoryInterface $customRepository,
        RequestInterface $request,
        CollectionFactory $customFactory

    ) {
        $this->customRepository = $customRepository;
        $this->customInterfaceFactory = $customInterfaceFactory;
        $this->request = $request;
        $this->customFactory = $customFactory;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $date = date("m/d/Y h:i:s a", time());
        $product = $observer->getproduct();
        $sku = $product->getSKU();
        $id = $product->getId();

        $collection = $this->customInterfaceFactory->create();
        
        if (!empty($this->request->getParam('id'))) {

            $pid = $this->request->getParam('id');

            $custom =  $this->customFactory->create();

            $custom->addFieldToFilter('entity_id',$id);
            
            foreach($custom as $item) {
               
                $customid = $item->getId();
            }
            $update = $this->customRepository->getById($customid);
            $update->setEntityId($id);
            $update->setSku($sku);
            $update->setUpdatedAt($date);
            $this->customRepository->save($update);
        } else {
            $collection->setEntityId($id);
            $collection->setSku($sku);
            $collection->setCreatedAt($date);
            $collection->setUpdatedAt($date);
            $this->customRepository->save($collection);
        }
    }
}
