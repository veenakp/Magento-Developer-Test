<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'DL_CustomModule',
    __DIR__
);
