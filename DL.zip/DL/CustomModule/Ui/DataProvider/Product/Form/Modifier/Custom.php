<?php

/**
 * @package DL_CustomModule
 */

namespace DL\CustomModule\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Ui\Component\Form\Fieldset;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Ui\Component\Form\Element\Input;

class Custom extends AbstractModifier
{   
    protected $scopeConfig;
    private $locator;

    public function __construct(
        
        ScopeConfigInterface $scopeConfig,
        LocatorInterface $locator
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->locator = $locator;
    }
    /**
     * {@inheritdoc}
     */
    public function modifyData(array $data)
    {
        $product   = $this->locator->getProduct();
        $productId = $product->getId();
        $data = array_replace_recursive(
            $data, [
                $productId => [
                    'magenest' => [
                        'textField' => $this->scopeConfig->getValue('products/general/display_text', ScopeInterface::SCOPE_STORE),
                    ]
                ]
            ]);
        return $data;
    }
    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    {
        $meta = array_replace_recursive(
            $meta,
            [
                'magenest' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'label' => __('Product Disclaimer Fields'),
                                'collapsible' => true,
                                'componentType' => Fieldset::NAME,
                                'dataScope' => 'data.magenest',
                                'sortOrder' => 10
                            ],
                        ],
                    ],
                    'children' => $this->getFields()
                ],
            ]
        );

        return $meta;
    }
    protected function getFields()
    {
        return [
            'textField' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label'         => __('Product Disclaimer'),
                            'componentType' => Field::NAME,
                            'formElement'   => Input::NAME,
                            'dataScope'     => 'textField',
                            'dataType'      => Text::NAME,
                            'sortOrder'     => 20,
                        ],
                    ],
                ],
            ]
        ];
    }
}
?>
