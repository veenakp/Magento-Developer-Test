<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use DL\CustomModule\Api\Data\CustomInterface;

interface CustomRepositoryInterface
{

    /**
     * @param CustomInterface $data
     * @return mixed
     */
    public function save(CustomInterface $data);

    /**
     * @param $dataId
     * @return mixed
     */
    public function getById($dataId);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return \DL\CustomModule\Api\Data\CustomSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
