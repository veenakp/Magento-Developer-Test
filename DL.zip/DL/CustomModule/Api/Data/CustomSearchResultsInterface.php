<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface CustomSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get data list.
     *
     * @return \DL\CustomModule\Api\Data\CustomInterface[]
     */
    public function getItems();

    /**
     * Set data list.
     *
     * @param \DL\CustomModule\Api\Data\CustomInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
