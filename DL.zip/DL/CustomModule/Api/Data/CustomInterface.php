<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Api\Data;

interface CustomInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const CUSTOM_ID   = 'custom_id';
    const ENTITY_ID   = 'entity_id';
    const SKU         = 'sku';
    const VENDOR_NUMBER     = 'vendor_number';
    const VENDOR_NOTE       = 'vendor_note';
    const CREATED_AT        = 'created_at';
    const UPDATED_AT        = 'updated_at';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set ID
     *
     * @param $id
     * @return CustomInterface
     */
    public function setId($id);

    /**
     * Get Product EntityId
     *
     * @return int
     */
    public function getEntityId();

    /**
     * Set Product EntityId
     *
     * @param $entity_id
     * @return int
     */
    public function setEntityId($entity_id);

    /**
     * Get SKU
     *
     * @return string
     */
    public function getSku();

    /**
     * Set SKU
     *
     * @param $sku
     * @return mixed
     */
    public function setSku($sku);

    /**
     * Get Vendor Number
     *
     * @return mixed
     */
    public function getVendorNumber();

    /**
     * Set Vendor Number
     *
     * @param $vendor_number
     * @return mixed
     */
    public function setVendorNumber($vendor_number);

    /**
     * Get Vendor Note
     *
     * @return mixed
     */
    public function getVendorNote();

    /**
     * Set Vendor Note
     *
     * @param $vendor_note
     * @return mixed
     */
    public function setVendorNote($vendor_note);

    /**
     * Get Created At
     *
     * @return mixed
     */
    public function getCreatedAt();

    /**
     * Set Created At
     *
     * @param $craeted_at
     * @return mixed
     */
    public function setCreatedAt($created_at);

    /**
     * Get Updated At
     *
     * @return mixed
     */
    public function getUpdatedAt();

    /**
     * Set Updated At
     *
     * @param $updated_at
     * @return mixed
     */
    public function setUpdatedAt($updated_at);
}
