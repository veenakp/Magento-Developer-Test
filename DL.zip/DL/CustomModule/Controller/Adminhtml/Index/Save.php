<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use DL\CustomModule\Model\CustomFactory;
use Magento\Framework\App\RequestInterface;
use DL\CustomModule\Api\Data\CustomInterfaceFactory;
use DL\CustomModule\Api\CustomRepositoryInterface;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var CustomRepositoryInterface
     */
    private $customRepository;

    /**
     * @var CustomInterfaceFactory
     */
    private $CustomInterfaceFactory;
    /**
     * @var CustomData
     */
    private $customFactory;
    /**
     * @var RequestInterface
     */
    private $request;
    /**
     * @var CustomFactory
     */
    private $customItem;

    /**
     * @param Context $context
     * @param RequestInterface $request
     * @param CustomFactory $customItem
     * @param CustomInterfaceFactory $customInterfaceFactory
     * @param CustomRepositoryInterface $customRepository
     */
    public function __construct(
        Context $context,
        RequestInterface $request,
        CustomFactory $customItem,
        CustomInterfaceFactory $customInterfaceFactory,
        CustomRepositoryInterface $customRepository
    ) {
        $this->request = $request;
        $this->customItem = $customItem;
        $this->customRepository = $customRepository;
        $this->customInterfaceFactory = $customInterfaceFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->request->getPostValue();

        $date = date("m/d/Y h:i:s a", time());

        if (isset($data['custom_id'])) {
            $collection = $this->customRepository->getById($data['custom_id']);
            $collection->setEntityId($data['entity_id']);
            $collection->setSku($data['sku']);
            $collection->setVendorNumber($data['vendor_number']);
            $collection->setVendorNote($data['vendor_note']);
            $collection->setCreatedAt($data['created_at']);
            $collection->setUpdatedAt($data['updated_at']);
            $this->customRepository->save($collection);
            return $resultRedirect->setPath('productmng/index/index');
        } else {
            $collection = $this->customInterfaceFactory->create();
            $collection->setEntityId($data['entity_id']);
            $collection->setSku($data['sku']);
            $collection->setVendorNumber($data['vendor_number']);
            $collection->setVendorNote($data['vendor_note']);
            $collection->setCreatedAt($data['created_at']);
            $collection->setUpdatedAt($data['updated_at']);
            $this->customRepository->save($collection);
            return $resultRedirect->setPath('productmng/index/index');
        }
    }
}
