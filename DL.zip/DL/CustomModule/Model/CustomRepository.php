<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use DL\CustomModule\Model\CustomFactory;
use DL\CustomModule\Api\Data\CustomInterface;
use DL\CustomModule\Model\ResourceModel\Custom;
use DL\CustomModule\Api\Data\CustomInterfaceFactory;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Api\SearchCriteriaInterface;
use DL\CustomModule\Api\Data\CustomSearchResultsInterfaceFactory;
use Magento\Framework\Reflection\DataObjectProcessor;
use DL\CustomModule\Model\ResourceModel\Custom\CollectionFactory;

class CustomRepository implements \DL\CustomModule\Api\CustomRepositoryInterface
{
    /**
     * @var customFactory
     */
    private $customFactory;
    /**
     * @var ResourceModel\Custom
     */
    private $customResource;
    /**
     * @var \DL\CustomModule\Api\Data\CustomInterfaceFactory
     */
    private $customDataFactory;
    /**
     * @var \Magento\Framework\Api\ExtensibleDataObjectConverter
     */
    private $dataObjectConverter;
    /**
     * @var DataObjectHelper
     */
    private  $dataObjectHelper;
    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;
    /**
     * @var CustomSearchResultsInterfaceFactory
     */
    private $searchResultFactory;
    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * CustomRepository constructor.
     * @param CustomFactory                       $customFactory
     * @param Custom                              $customResource
     * @param CustomInterfaceFactory              $customDataFactory
     * @param ExtensibleDataObjectConverter       $dataObjectConverter
     * @param DataObjectHelper                    $dataObjectHelper
     * @param CustomSearchResultsInterfaceFactory $searchResultFactory
     * @param DataObjectProcessor                 $dataObjectProcessor
     * @param CollectionProcessorInterface        $collectionProcessor
     * @param CollectionFactory                   $collectionFactory
     */
    public function __construct(
        CustomFactory                       $customFactory,
        Custom                              $customResource,
        CustomInterfaceFactory              $customDataFactory,
        ExtensibleDataObjectConverter       $dataObjectConverter,
        DataObjectHelper                    $dataObjectHelper,
        CustomSearchResultsInterfaceFactory $searchResultFactory,
        DataObjectProcessor                 $dataObjectProcessor,
        CollectionProcessorInterface        $collectionProcessor,
        CollectionFactory                   $collectionFactory
    ) {
        $this->customFactory       = $customFactory;
        $this->customResource      = $customResource;
        $this->customDataFactory   = $customDataFactory;
        $this->dataObjectConverter = $dataObjectConverter;
        $this->dataObjectHelper    = $dataObjectHelper;
        $this->searchResultFactory = $searchResultFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->collectionFactory   = $collectionFactory;
    }

    /**
     * @param int $customId
     * @return CustomInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($custom_id)
    {
        $customObj = $this->customFactory->create();
        $this->customResource->load($customObj, $custom_id);
        if (!$customObj->getId()) {
            throw new NoSuchEntityException(__('Item with id "%1" does not exist.', $custom_id));
        }
        $data = $this->customDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $data,
            $customObj->getData(),
            CustomInterface::class
        );
        $data->setId($customObj->getId());
        return $data;
    }

    /**
     * Save Custom Data
     *
     * @param CustomInterface
     * @return CustomInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(CustomInterface $custom)
    {
        try {
            /** @var CustomInterface|\Magento\Framework\Model\AbstractModel $data */
            $this->customResource->save($custom);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the data: %1',
                $exception->getMessage()
            ));
        }
        return $custom;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return \DL\CustomModule\Api\Data\CustomsSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->collectionFactory->create();

        $this->collectionProcessor->process($searchCriteria, $collection);

        $searchResults = $this->searchResultFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
}
