<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Model;

use Magento\Framework\Model\AbstractModel;
use DL\CustomModule\Api\Data\CustomInterface;

class Custom extends AbstractModel
implements CustomInterface
{

    /**
     * Cache tag
     */
    const CACHE_TAG = 'custom_product';

    /**
     * Initialise resource model
     */
    protected function _construct()
    {
        $this->_init('DL\CustomModule\Model\ResourceModel\Custom');
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Id
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(CustomInterface::CUSTOM_ID);
    }

    /**
     * Get Entity Id
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(CustomInterface::ENTITY_ID);
    }

    /**
     * Set entity id
     *
     * @param $entity_id
     * @return $this
     */
    public function setEntityId($entity_id)
    {
        return $this->setData(CustomInterface::ENTITY_ID, $entity_id);
    }

    /**
     * Get sku
     *
     * @return string
     */
    public function getSku()
    {
        return $this->getData(CustomInterface::SKU);
    }

    /**
     * Set sku
     *
     * @param $sku
     * @return $this
     */
    public function setSku($sku)
    {
        return $this->setData(CustomInterface::SKU, $sku);
    }

    /**
     * Get vendor number
     *
     * @return string
     */
    public function getVendorNumber()
    {
        return $this->getData(CustomInterface::VENDOR_NUMBER);
    }
    /**
     * Set vendor number
     *
     * @param $vendor_number
     * @return $this
     */
    public function setVendorNumber($vendor_number)
    {
        return $this->setData(CustomInterface::VENDOR_NUMBER, $vendor_number);
    }

    /**
     * Get vendor note
     *
     * @return string
     */
    public function getVendorNote()
    {
        return $this->getData(CustomInterface::VENDOR_NOTE);
    }

    /**
     * Set vendor note
     *
     * @param $vendor_note
     * @return $this
     */
    public function setVendorNote($vendor_note)
    {
        return $this->setData(CustomInterface::VENDOR_NOTE, $vendor_note);
    }

    /**
     * Get Created At
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(CustomInterface::CREATED_AT);
    }

    /**
     * Set Created At
     *
     * @param $created_at
     * @return $this
     */
    public function setCreatedAt($created_at)
    {
        return $this->setData(CustomInterface::CREATED_AT, $created_at);
    }

    /**
     * Get Updated At
     *
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(CustomInterface::UPDATED_AT);
    }

    /**
     * Set Updated At
     *
     * @param $updated_at
     * @return $this
     */
    public function setUpdatedAt($updated_at)
    {
        return $this->setData(CustomInterface::UPDATED_AT, $updated_at);
    }
}
