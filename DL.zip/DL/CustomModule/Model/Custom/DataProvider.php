<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Model\Custom;

use Magento\Ui\DataProvider\AbstractDataProvider;
use DL\CustomModule\Model\ResourceModel\Custom\CollectionFactory;

class DataProvider extends AbstractDataProvider
{
    /**
     * @var CollectionFactory
     */
    private $customFactory;

    private $loadedData;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $countryFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $customFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->customFactory = $customFactory;
        $this->collection = $this->customFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $data) {
            $requestData = $data->getData();
            $this->loadedData[$data->getId()] = $requestData;
        }
        return $this->loadedData;
    }
    public function addFieldToSearchFilter($field, $condition = null)
    {
        $field = $this->_getMappedField($field);
        $this->_select->orWhere($this->_getConditionSql($field, $condition));
        return $this;
    }
}
