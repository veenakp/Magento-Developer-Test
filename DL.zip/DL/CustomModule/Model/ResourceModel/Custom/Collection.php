<?php

/**
 * @package DL_CustomModule
 */

declare(strict_types=1);

namespace DL\CustomModule\Model\ResourceModel\Custom;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'custom_id';

    /**
     * Collection initialisation
     */
    protected function _construct()
    {
        $this->_init('DL\CustomModule\Model\Custom', 'DL\CustomModule\Model\ResourceModel\Custom');
    }

    public function addFieldToFilter($field, $condition = null)
    {

        return parent::addFieldToFilter($field, $condition);
    }

    public function addFieldToSearchFilter($field, $condition = null)
    {
        $field = $this->_getMappedField($field);
        $this->_select->orWhere($this->_getConditionSql($field, $condition));
        return $this;
    }
}
